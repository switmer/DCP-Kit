import fs from 'fs';
import path from 'path';
import { parseTSX } from '../core/parser.js';
import { enrichWithLLM } from '../core/llmEnrichment.js';
import { buildManifest, flattenTokenTree } from '../core/registryBuilder.js';
import { readJSON, writeJSON, getAllFiles } from '../core/utils.js';

export async function runBuild({ config, llm: cliLLM }) {
  if (!fs.existsSync(config)) {
    throw new Error(`Config file not found at ${config}`);
  }

  const cfg = readJSON(config);
  if (!cfg) {
    throw new Error(`Invalid config JSON in ${config}`);
  }

  // CLI flag takes precedence over config
  const llm = cliLLM === true || cfg.llmEnrich === true;
  
  // Make all paths relative to the config file
  const rootDir = path.dirname(config);
  const manifestFilePath = path.join(rootDir, cfg.output);
  
  // Ensure output directory for the manifest exists
  if (!manifestFilePath) {
    throw new Error('Output path (manifestFilePath) is not defined in the config file.');
  }
  const manifestDir = path.dirname(manifestFilePath);
  fs.mkdirSync(manifestDir, { recursive: true });
  
  // Output directories for components and tokens are relative to the manifest file's directory
  const componentsOutDir = path.join(manifestDir, 'components');
  const tokensOutDir = path.join(manifestDir, 'tokens');
  fs.mkdirSync(componentsOutDir, { recursive: true });
  fs.mkdirSync(tokensOutDir, { recursive: true });

  const compDir = path.join(rootDir, cfg.componentSource || cfg.components);
  const components = [];

  // Process components
  if (!compDir || !fs.existsSync(compDir)) {
    throw new Error(`Components directory not found at ${compDir}. Please check the 'components' path in your config: ${config}`);
  }
  for (const fp of getAllFiles(compDir, '.tsx')) {
    let comp = parseTSX(path.join(compDir, fp));
    if (llm) {
      comp = await enrichWithLLM(comp);
    }
    writeJSON(path.join(componentsOutDir, `${comp.name}.dcp.json`), comp);
    components.push({ 
      name: comp.name, 
      path: `./components/${comp.name}.dcp.json`,
      category: comp.category || 'Components'
    });
  }

  // Process tokens
  const tokens = [];
  const tokenSources = Array.isArray(cfg.tokens) ? cfg.tokens : (cfg.tokens ? [cfg.tokens] : []);
  for (const tokenPath of tokenSources) {
    const tokenDir = path.join(rootDir, tokenPath);
    if (!tokenDir || !fs.existsSync(tokenDir)){
      // If it's a file path for tokens
      if(fs.existsSync(tokenPath) && fs.statSync(tokenPath).isFile()) {
         const tokenData = readJSON(tokenPath);
         const flattened = flattenTokenTree(tokenData);
         const outPath = path.join(tokensOutDir, path.basename(tokenPath));
         writeJSON(outPath, flattened);
         tokens.push({ 
           name: path.basename(tokenPath, '.json'),
           path: `./tokens/${path.basename(tokenPath)}`
         });
         continue; // Move to next token source
      } else {
        throw new Error(`Token source not found at ${tokenDir} (or ${tokenPath} if absolute). Please check the 'tokens' path in your config: ${config}`);
      }
    }
    const tokenFiles = getAllFiles(tokenDir);
    for (const tf of tokenFiles) {
      const tokenData = readJSON(path.join(tokenDir, tf));
      const flattened = flattenTokenTree(tokenData);
      const outPath = path.join(tokensOutDir, path.basename(tf));
      writeJSON(outPath, flattened);
      tokens.push({ 
        name: path.basename(tf, '.json'),
        path: `./tokens/${path.basename(tf)}`
      });
    }
  }

  // Build and write manifest
  const manifest = buildManifest({
    registryName: cfg.registryName || 'Design System',
    registryVersion: cfg.version || '1.0.0',
    components,
    tokens,
    generator: {
      cli: 'dcp-transformer',
      version: '1.2.0',
      llmUsed: llm,
      schemaVersion: '1.0.0'
    },
    outputPath: manifestFilePath // Pass the direct manifest file path
  });

  console.log('✅ Build artifacts written to base directory:', manifestDir);

  // Return for test assertions
  return { components, tokens, outputPath: manifestFilePath, manifest };
}