# DCP Transformer

[![npm version](https://badge.fury.io/js/dcp-transformer.svg)](https://badge.fury.io/js/dcp-transformer)
[![Test Status](https://github.com/yourusername/dcp-transformer/workflows/tests/badge.svg)](https://github.com/yourusername/dcp-transformer/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Transform your design system into a DCP (Design Component Protocol) registry for AI-powered workflows.

## Features

- 🔍 **Analyze** design systems and generate DCP registries
- 🎨 **Transform** components and tokens into DCP format
- 🤖 **Enrich** metadata using LLM capabilities
- 📊 **Report** on token usage and coverage
- 🔄 **Compare** registries across versions
- 🚀 **Serve** as an MCP-compatible endpoint

## Installation

```bash
npm install -g dcp-transformer
```

## Quick Start

```bash
# Initialize from an existing design system
dcp-transformer analyze ./path-to-design-system --llm

# Or build from specific sources
dcp-transformer build \
  --components ./src/components \
  --tokens ./tokens/theme.json \
  --docs ./docs

# Serve the registry with MCP compatibility
dcp-transformer serve --mcp --preview
```

## Commands

### analyze
Analyze a design system and generate DCP registry:
```bash
dcp-transformer analyze <source> [options]
  --llm        Enable LLM enrichment
```

### build
Build DCP registry from components and tokens:
```bash
dcp-transformer build [options]
  --config <path>   Path to config (default: ./dcp.config.json)
  --llm            Use LLM enrichment
```

### serve
Start MCP-compatible server:
```bash
dcp-transformer serve [options]
  --mcp           Enable MCP endpoints
  --preview       Serve browse UI
  --auth <token>  API token
```

### validate
Validate the DCP registry:
```bash
dcp-transformer validate
```

### report
Generate token usage reports:
```bash
dcp-transformer report
dcp-transformer report:coverage
```

### diff
Compare two DCP registries:
```bash
dcp-transformer diff <old> <new>
```

### publish
Upload registry to S3/CDN:
```bash
dcp-transformer publish --bucket my-bucket
```

## Debug Mode

Add `--verbose` to any command for detailed logging:
```bash
dcp-transformer build --verbose
```

## Agent Integration

The DCP Transformer serves as a bridge between your design system and AI agents. When running in MCP mode, it provides:

- 🔌 **RPC Endpoints** for component/token queries
- 📡 **SSE Updates** for real-time changes
- 🔐 **Auth Support** for secure access
- 📊 **Analytics** for usage tracking

Example agent integration:
```javascript
const registry = await fetch('http://localhost:7400/context/registry').then(r => r.json());
const component = await fetch('http://localhost:7400/context/components/Button').then(r => r.json());
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.
