import fs from 'fs';
import path from 'path';
import { withCustomConfig } from 'react-docgen-typescript';

export function extractTailwindTokens(source) {
  const tokens = {};
  const rgx = /class(Name)?=["'`](.*?)["'`]/g;
  let match;
  while ((match = rgx.exec(source))) {
    match[2].split(/\s+/).forEach(cls => {
      const clean = cls.replace(/^[^:]+:/, '');
      if (clean.startsWith('bg-')) tokens.background = `color.surface.${clean.slice(3).replace(/-/g, '.')}`;
      if (clean.startsWith('text-')) tokens.text = `color.text.${clean.slice(5).replace(/-/g, '.')}`;
      if (clean.startsWith('px-')) tokens.paddingX = `spacing.${clean.slice(3)}`;
      if (clean.startsWith('py-')) tokens.paddingY = `spacing.${clean.slice(3)}`;
      if (clean === 'rounded') tokens.borderRadius = 'radius.default';
    });
  }
  return tokens;
}

const parser = withCustomConfig('./tsconfig.json', {
  savePropValueAsString: true,
  shouldExtractLiteralValuesFromEnum: true
});

export function parseTSX(filePath) {
  const meta = parser.parse(filePath)[0];
  const src = fs.readFileSync(filePath, 'utf-8');
  const props = {};
  Object.entries(meta.props || {}).forEach(([key, p]) => {
    props[key] = {
      type: p.type.name,
      description: p.description,
      required: p.required,
      default: p.defaultValue?.value,
      source: 'source'
    };
  });

  return {
    name: meta.displayName || path.basename(filePath, '.tsx'),
    description: meta.description || '',
    props,
    tokensUsed: extractTailwindTokens(src)
  };
}
