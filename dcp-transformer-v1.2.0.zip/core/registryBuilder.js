import { readJSON, writeJSON, getAllFiles } from './utils.js';
import { enrichComponent, enrichToken } from './llmEnrichment.js';

export function flattenTokenTree(tokens, prefix = '') {
  const flattened = {};
  for (const [key, value] of Object.entries(tokens)) {
    const path = prefix ? `${prefix}.${key}` : key;
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      Object.assign(flattened, flattenTokenTree(value, path));
    } else {
      flattened[path] = value;
    }
  }
  return flattened;
}

export function buildManifest({
  registryName,
  registryVersion,
  components, // Array of component objects
  tokens,     // Array of token file objects (like { name: 'theme', path: './tokens/theme.json' })
              // OR it could be the already flattened and processed token object from build.js
  generator,
  outputPath  // Still needed to write the manifest file
}) {
  if (!registryName || !registryVersion || !components || !tokens || !generator || !outputPath) {
    console.error('buildManifest missing required parameters:', { registryName, registryVersion, components_isArray: Array.isArray(components), tokens_isArray: Array.isArray(tokens), generator_exists: !!generator, outputPath });
    throw new Error('buildManifest: Missing required configuration parameters');
  }

  const manifest = {
    registryName,
    version: registryVersion,
    components,
    tokens, // Assuming this is the structure commands/build.js passes
    generator,
    generated: new Date().toISOString(),
  };

  // Write output
  writeJSON(outputPath, manifest);
  console.log('📦 Manifest written to', outputPath);
  return manifest;
}

export async function buildRegistry({ componentsPath, tokensPath, outputPath }) {
  // Read and validate config
  if (!componentsPath || !tokensPath || !outputPath) {
    throw new Error('Missing required configuration');
  }

  // Read tokens
  const tokensData = readJSON(tokensPath);
  if (!tokensData) {
    throw new Error('Failed to read tokens file');
  }

  // Process components
  const components = [];
  const componentFiles = getAllFiles(componentsPath);
  
  for (const file of componentFiles) {
    try {
      const component = readJSON(file);
      if (component) {
        const enrichedComponent = await enrichComponent(component);
        components.push(enrichedComponent);
      }
    } catch (err) {
      console.error(`Failed to process component ${file}:`, err);
    }
  }

  // Process tokens (flattening and enriching)
  const flatTokens = flattenTokenTree(tokensData);
  const enrichedTokens = {};
  for (const [key, value] of Object.entries(flatTokens)) {
    // Assuming enrichToken can handle a simple value if needed, or token structure is { value, type, ...}
    enrichedTokens[key] = await enrichToken(value); 
  }

  // Build registry
  const registry = {
    components,
    tokens: enrichedTokens,
    version: '1.1.0', // This should come from config or package.json
    generated: new Date().toISOString()
  };

  // Write output
  writeJSON(outputPath, registry);
  return registry;
} 