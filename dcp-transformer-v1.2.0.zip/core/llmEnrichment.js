import OpenAI from 'openai';

// Export the client so tests can override it
export let openai = null;

export function initializeOpenAI(apiKey) {
  try {
    openai = new OpenAI({
      apiKey: apiKey || process.env.OPENAI_API_KEY
    });
    return true;
  } catch (err) {
    console.warn('⚠️ Failed to initialize OpenAI client:', err.message);
    return false;
  }
}

// Initialize by default if API key is available
initializeOpenAI();

export async function enrichWithLLM(component) {
  if (!openai) {
    console.warn(`⚠️ Skipping LLM enrichment for ${component.name} - No API key available`);
    return component;
  }

  const prompt = buildPrompt(component);

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: SYSTEM_INSTRUCTION },
        { role: 'user', content: prompt }
      ],
      temperature: 0.3
    });

    const enriched = JSON.parse(response.choices[0].message.content);

    // Deep merge props, preserving original values and adding new ones
    const mergedProps = {};
    const allPropKeys = new Set([
      ...Object.keys(component.props || {}),
      ...Object.keys(enriched.props || {})
    ]);

    for (const key of allPropKeys) {
      mergedProps[key] = {
        ...component.props?.[key],
        ...enriched.props?.[key]
      };
      
      // Tag LLM-enriched fields
      if (!component.props?.[key]?.description && mergedProps[key].description) {
        mergedProps[key].source = 'llm';
      }
    }

    // Create the merged component
    const merged = {
      ...component,
      description: enriched.description || component.description,
      props: mergedProps,
      states: enriched.states || component.states || [],
      documentation: {
        ...component.documentation,
        ...enriched.documentation
      },
      examples: [
        ...(component.examples || []),
        ...(enriched.examples || [])
      ]
    };

    // Add enrichment metadata
    const originalCount = Object.keys(component.props || {}).length;
    const enrichedCount = Object.keys(merged.props || {}).length;
    merged.enrichmentMeta = {
      enrichedAt: new Date().toISOString(),
      enrichedBy: 'openai:gpt-4',
      fieldsAdded: Math.max(0, enrichedCount - originalCount)
    };

    return merged;
  } catch (e) {
    if (e instanceof SyntaxError) {
      console.warn(`⚠️ Failed to parse JSON for ${component.name}. Raw content:`, 
        response?.choices?.[0]?.message?.content || 'No content available');
    } else {
      console.warn(`⚠️ LLM enrichment failed for component: ${component.name}`, e.message);
    }
    return component;
  }
}

// Alias for backward compatibility with tests
export { enrichWithLLM as enrichComponent };

// Token enrichment function
export async function enrichToken(token) {
  if (!openai) {
    console.warn(`⚠️ Skipping LLM enrichment for token - No API key available`);
    return token;
  }

  const prompt = `
Analyze this design token and provide:
1. A clear description of its purpose and usage
2. Common use cases
3. Any accessibility considerations

Token: ${JSON.stringify(token, null, 2)}

Return only valid JSON with the enriched token data.
`;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: 'You are a design system expert helping to document design tokens.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.3
    });

    const enriched = JSON.parse(response.choices[0].message.content);
    return {
      ...token,
      ...enriched,
      enrichmentMeta: {
        enrichedAt: new Date().toISOString(),
        enrichedBy: 'openai:gpt-4'
      }
    };
  } catch (e) {
    console.warn(`⚠️ LLM enrichment failed for token:`, e.message);
    return token;
  }
}

const SYSTEM_INSTRUCTION = `
You are an expert UI engineer and accessibility consultant. You help normalize design system component definitions.
When given a partially filled component object, return a complete JSON object with:
- descriptions for each prop
- inferred states
- usage guidelines
- accessibility notes
- at least one usage example (label + code)
Return ONLY valid JSON. Do not explain anything else.
`;

function buildPrompt(component) {
  const partial = {
    name: component.name,
    description: component.description,
    props: component.props,
    states: component.states || [],
    tokensUsed: component.tokensUsed,
    documentation: component.documentation || {},
    examples: component.examples || []
  };

  return `
Here is a partially filled design component definition:

${JSON.stringify(partial, null, 2)}

Fill in missing fields and return the enriched JSON object.
`;
}