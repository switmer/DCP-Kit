import fs from 'fs';
import path from 'path';

export const readJSON = p => JSON.parse(fs.readFileSync(p, 'utf8'));
export const writeJSON = (p, obj) =>
  fs.writeFileSync(p, JSON.stringify(obj, null, 2));

export const getAllFiles = (dir, ext = '.json') =>
  fs.readdirSync(dir).filter(f => f.endsWith(ext));

export const flatten = (obj, prefix = '', out = {}) => {
  Object.entries(obj).forEach(([k, v]) => {
    const key = prefix ? `${prefix}.${k}` : k;
    v?.value !== undefined
      ? (out[key] = v)
      : flatten(v, key, out);
  });
  return out;
};
