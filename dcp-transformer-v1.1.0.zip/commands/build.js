import fs from 'fs';
import path from 'path';
import { parseTSX } from '../core/parser.js';
import { enrichWithLLM } from '../core/llmEnrichment.js';
import { buildManifest, flattenTokenTree } from '../core/registryBuilder.js';

export async function runBuild({ config, llm }) {
  const cfg = JSON.parse(fs.readFileSync(config, 'utf-8'));
  const out = path.resolve(cfg.outputPath);
  fs.mkdirSync(out + '/components', { recursive: true });
  fs.mkdirSync(out + '/tokens', { recursive: true });

  const files = fs
    .readdirSync(cfg.componentSource)
    .filter(f => f.endsWith('.tsx') || f.endsWith('.json'));

  const components = [];
  for (const file of files) {
    const full = path.join(cfg.componentSource, file);
    const comp =
      file.endsWith('.tsx')
        ? parseTSX(full)
        : JSON.parse(fs.readFileSync(full, 'utf-8'));

    const enriched = llm ? await enrichWithLLM(comp) : comp;
    const dest = path.join(out, 'components', `${enriched.name}.dcp.json`);
    fs.writeFileSync(dest, JSON.stringify(enriched, null, 2));
    components.push({
      name: enriched.name,
      path: `./components/${enriched.name}.dcp.json`,
      category: enriched.category || 'Uncategorized',
      tags: enriched.tags || [],
      description: enriched.description || '',
    });
  }

  /* ---- tokens ---- */
  const rawTokens = JSON.parse(fs.readFileSync(cfg.tokenSources[0], 'utf-8'));
  fs.writeFileSync(
    path.join(out, 'tokens', 'theme.dcp.json'),
    JSON.stringify(rawTokens, null, 2)
  );

  /* ---- manifest ---- */
  const manifest = buildManifest({
    registryName: cfg.registryName,
    registryVersion: cfg.registryVersion,
    components,
    tokens: [{ name: 'theme', path: './tokens/theme.dcp.json' }],
    config: cfg,
    llmUsed: !!llm,
  });
  fs.writeFileSync(path.join(out, 'manifest.json'), JSON.stringify(manifest, null, 2));

  console.log('✅ Build finished • files in', out);
}