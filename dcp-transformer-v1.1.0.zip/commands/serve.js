import { startMCPServer } from '../core/mcpServer.js';

export function startServer(opts) {
  startMCPServer({
    registryPath: './dcp-registry',
    port: opts.port || 7400,
    enableMCP: !!opts.mcp,
    enablePreview: !!opts.preview,
    auth: opts.auth
  });
}
