import path from 'path';
import fs from 'fs';
import Ajv from 'ajv';
import { getAllFiles, readJSON } from '../core/utils.js';

export function validateRegistry() {
  const ajv = new Ajv({ allErrors: true });
  const compSchema = readJSON('./schemas/dcp.component.schema.json');
  const validate = ajv.compile(compSchema);

  const failures = [];
  getAllFiles('./dcp-registry/components').forEach(f => {
    const data = readJSON(`./dcp-registry/components/${f}`);
    if (!validate(data)) failures.push({ f, errors: validate.errors });
  });

  if (failures.length) console.error(failures);
  else console.log('🎉 All components valid');
}
