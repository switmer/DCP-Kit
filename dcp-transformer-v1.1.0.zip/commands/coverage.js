import fs from 'fs';
import path from 'path';
import { getAllFiles, readJSON } from '../core/utils.js';

export function generateCoverageReport({ componentsPath = './dcp-registry/components', outputPath = './dcp-reports/coverage.json' }) {
  const files = getAllFiles(componentsPath);
  const report = {
    total: files.length,
    missingDescriptions: [],
    llmFields: 0
  };

  files.forEach(f => {
    const c = readJSON(path.join(componentsPath, f));
    if (!c.description) report.missingDescriptions.push(c.name);
    Object.values(c.props || {}).forEach(p => {
      if (p.source === 'llm') report.llmFields++;
    });
  });

  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, JSON.stringify(report, null, 2));
  console.log('📝 Coverage written to', outputPath);
}
